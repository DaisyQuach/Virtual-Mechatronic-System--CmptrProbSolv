function [theta4] = ThetaFour(L_vector, theta2)
%LinkageAngles calculates linkage angles from servo motor angle
%   Use servo motor and length vector to find angle of cannon
% initialize L values
length1 = L_vector (1);
length2 = L_vector (2);
length3 = L_vector (3);
length4 = L_vector (4);

% initialize theta2

% compute K values
K1 = length1/length2;
K2 = length1/length4;
K3 = (length1 ^ 2 + length2 ^ 2 - length3 ^ 2 + length4 ^ 2) / (2 * length2 * length4);

% compute A, B, C
A = cosd (theta2) - K1 - (K2 .* cosd (theta2)) + K3;
B = -2 .* sind (theta2);
C = K1 - (K2 + 1) .* cosd (theta2) + K3;

% call quadratic
root1 = Quadratic(A, B, C, -1);
% compute theta4
theta4 = 2 * atand (root1);

end