function [x0, y0] = InitialCoords(distanceVector, theta)
% InitialCoords Calculate the initial position of a launcher given 3
% distances and 1 angle
%   Inputs: d1: length of leg 1, in meters
%           d2: length of leg 2, in meters
%           d3: length of leg 3, in meters
%           theta: angle between d2 and horizontal, in degrees
% Gavin Tobin, u1227373, ME EN 1010, HW8

    %index out variables
    d1 = distanceVector (1);
    d2 = distanceVector (2);
    d3 = distanceVector (3);
    
    x0 = d2 * cosd(theta) - d3 * sind(theta);
    y0 = d1 + d2 * sind(theta) + d3 * cosd (theta);
end

