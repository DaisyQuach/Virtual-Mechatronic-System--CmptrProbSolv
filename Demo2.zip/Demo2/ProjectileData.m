function [launchAngles, aveDistance] = ProjectileData (filename)
%analyzes the data in an excel spreadsheet named "filename"
%gives launch angles and average horizontal distances

%intialize variables and read matrices and assign to different matrices
data = readmatrix (filename); %imports data


launchAnglesColumn = data (:,1); %makes launch angle array
launchAngles = launchAnglesColumn'; %makes launch angle array a row vector


expDistances = data (:,[2:end]); %makes distance array
aveDistanceCentimeter = mean(expDistances');
aveDistance = aveDistanceCentimeter ./ 100; %converts distances to meters from cm

    if nargout == 0
        %set up plot and plot distance versus range
        plot (launchAngles, aveDistance, 'ro');
        title ('Ping Pong Ball Projectile Data')
        xlabel ('Launch Angle [deg]')
        ylabel ('Horizontal Distance [m]') 
    end