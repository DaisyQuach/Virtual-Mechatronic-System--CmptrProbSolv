function [launchThetaVector] = LaunchAngle(distanceVector, v0, xTarget)
%Calcualtes launch angle to achieve a certain launch distance
%Gavin Tobin, u1227373, ME EN 1010, HW9
launchThetaVector = zeros (1, length(xTarget)); %set up the launchThetaVector 
    for i = 1:length(xTarget) %allow for any size vector xTarget 
        xTargetIndexed = xTarget (i); %index out certain xTarget
        [~, rangeAngle] = ProjectileRange2(distanceVector, v0);
        launchTheta = 90;
        xLand = 0;
            while (xLand < xTargetIndexed & launchTheta > rangeAngle)
                launchTheta = launchTheta - .01;        
                xLand = LandingDistance (distanceVector, v0, launchTheta);
            end
            launchThetaVector(i) = launchTheta; %put launch angles in a vector
        i = i + 1; %get out of for loop eventually
    end
end
