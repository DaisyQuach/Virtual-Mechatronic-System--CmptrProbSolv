function [range, rangeAngle] = ProjectileRange2(distanceVector, v0)
%ProjectileRange finds the maximum range of the projectile given d1, d2,
%d3, v0
%Gavin Tobin, u1227373, ME EN 1010, HW3

%initialize variables
theta = 0; %degrees
range = 0; %meters

%lengths of legs
d1 = distanceVector (1);
d2 = distanceVector (2);
d3 = distanceVector (3);

while (theta <= 90)
    tempPos = LandingDistance (distanceVector, v0, theta);
    if (tempPos > range)
        range = tempPos;
        rangeAngle = theta;
    end
    theta = theta + .01;
end

end

