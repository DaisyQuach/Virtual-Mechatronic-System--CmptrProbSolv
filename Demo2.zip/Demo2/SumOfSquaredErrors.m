function [summedSquareErrors] = SumOfSquaredErrors(a, b)
%calculate difference of between elements
    diff = a - b;
    %square result
    square = diff .^2;
    %sum vectors to get SSE
    summedSquareErrors = sum(square);
end
