function [root1] = Quadratic(a, b, c, plusOrMinus)
%Quadratic Calculates the quadratic function (-b +/- sqrt (b^2 - 4ac))/2a
%   Use form ax^2 + bx + c for inputs
%Gavin Tobin, u1227373, ME EN 1010, HW5
root1 = (-b + plusOrMinus .* sqrt(b .^ 2 - 4 .* a .* c)) ./ (2 .* a);

end
