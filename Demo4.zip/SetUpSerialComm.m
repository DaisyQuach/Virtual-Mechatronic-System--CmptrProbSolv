function [serialHandle] = SetUpSerialComm()
%StepUpSerialComm Summary of this function goes here
%   Detailed explanation goes here

    if (isempty(instrfind) == 0)
        fclose(instrfind)
        delete(instrfind)
    end
    
    serialHandle = serial('COM3', 'BaudRate', 57600);

end

