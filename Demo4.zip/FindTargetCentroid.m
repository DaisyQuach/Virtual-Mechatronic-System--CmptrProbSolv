function [centroidRow, centroidCol, modImage] = FindTargetCentroid(inputImage, targetRGB)
%Used to find the center of a target of a certain color
%Gavin Tobin, ME EN 1010, u1227373, HW10
%index out layers
redLayer = inputImage (:,:,1);
greenLayer = inputImage (:,:,2); 
blueLayer = inputImage (:,:,3);

logicalArray = ((redLayer == targetRGB(1)) & (greenLayer == targetRGB(2)) & (blueLayer == targetRGB(3)));

[rows, cols, ~] = size (inputImage);

%find top left corner of target
[firstMatchRow, firstMatchCol] = find (logicalArray == 1);
for r = firstMatchRow(1):rows %go through until you find a pixel that is not true in logical vector
     if (logicalArray(r + 1, firstMatchCol(1)) == 0) %current pixel is top right corner
        break;
    end
end
lastMatchRow = r;

for c = firstMatchCol(1):cols %go through until column in logical vector is not true
    if (logicalArray(firstMatchRow(1), c + 1) == 0) %current pixel is bottom left corner
        break;
    end
end
lastMatchCol = c;

%add fist and last pixels together and divide by two to find middle
centroidRow = (firstMatchRow(1) + lastMatchRow) / 2;
centroidCol = (firstMatchCol(1) + lastMatchCol) / 2;

%find new image array with blacked out targets
modImage = inputImage;
modImage (firstMatchRow:lastMatchRow, firstMatchCol:lastMatchCol, :) = 0;
end