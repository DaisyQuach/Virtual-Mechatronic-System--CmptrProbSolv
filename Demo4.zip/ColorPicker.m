function [RGB_Vector] = ColorPicker(image_RGB_Array)
%User can select a color and is returned the RGB values of the color
%Gavin Tobin, ME EN 1010, u1227373, HW10
figure;
image (image_RGB_Array);
axis image;

[col, row] = ginput (1);
rowRound = round(row);
colRound = round(col);

R = image_RGB_Array (rowRound, colRound, 1);
B = image_RGB_Array (rowRound, colRound, 2);
G = image_RGB_Array (rowRound, colRound, 3);

RGB_Vector = [R, B, G];
end

