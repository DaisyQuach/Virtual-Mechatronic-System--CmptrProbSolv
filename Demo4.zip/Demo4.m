function [imageFileName, messageCellArray] = Demo4(serialHandle,listboxHandle, statusHandle)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

    %Image code
    imageFileName = 'S21_CP_B1.bmp';
    targetingImage = imread(imageFileName);
    messageCellArray{1} = ['Using image',imageFileName];
    listboxHandle.Items = messageCellArray;
    drawnow
    fprintf ("Click on yellow part of the image");
    yellowRGB = ColorPicker (targetingImage) %find target RGB values
    fprintf("Click on a blue part of the image");
    blueRGB = ColorPicker (targetingImage)
    redTarget = yellowRGB(2) + blueRGB(2)
    greenTarget = yellowRGB(2) 
    blueTarget = yellowRGB(2) - blueRGB(2)
    targetRGB = [redTarget,greenTarget,blueTarget];

    [rowCoordVec, colCoordVec, targetsBlack] = FindAllTargetsCentroids(targetingImage, targetRGB);
    rowCoordVec, colCoordVec %display row and column coordinates

    %set up figure and plot image with centroids
    figure
    hold on
    image (targetsBlack)
    axis image
    plot (colCoordVec, rowCoordVec, 'wx')
    drawnow

    %find target values to send to arduino
    stripeNum = rowCoordVec ./ 10
    xTarget = (colCoordVec + 750)./ 1000 %adjust for offset and convert to meters
    
    fopen(serialHandle)
    statusHandle.Value = [serialHandle.Port, 'is', serialHandle.Status]
    drawnow

    % wait for ready message from Romeo
    while serialHandle.BytesAvailable == 0
       % do nothing (wait) 
    end
    readyMessage = fscanf(serialHandle);
    readyMessage = readyMessage(1:end - 2); %gets rid of line returns
    messageCellArray{end + 1} = 'Romeo is ready!';
    listboxHandle.Items = messageCellArray;
    drawnow
    
    for i = 1:6
        fprintf(serialHandle, '%d\n %1.3f\n', [stripeNum(i), xTarget(i)])
        

        % read message from Romeo Board and display
        while serialHandle.BytesAvailable == 0
            % do nothing (wait) 
        end
        message = fscanf(serialHandle);
        message = message(1:end - 2); %gets rid of line returns
        messageCellArray{end + 1} = message;
        listboxHandle.Items = messageCellArray;
        drawnow
    end
end

