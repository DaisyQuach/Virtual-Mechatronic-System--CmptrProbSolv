%%%%%%%%%%%%%%%%%%
% Gavin Tobin
% u1227373
% ME EN 1010 Lab Section 007
% HW10
% Due 1 Apr 2021
%%%%%%%%%%%%%%%%%%
clear,clc,close all;

%%
clear, clc, close all;
%import image and read colors
rgb_image1 = imread ('test_image1.bmp');
[RGB_Vector] = ColorPicker(rgb_image1)

%%
clear,clc, close all;
rgb_image2 = imread ('S21_PP_A1.bmp');
fprintf ("Click on the target rectangle")
[targetRGB_vector] = ColorPicker(rgb_image2); %find RGB target value
[centroidRow, centroidCol, targetBlack] = FindTargetCentroid(rgb_image2, targetRGB_vector);
centroidRow %display row coordinates
centroidCol %display column coordinates
%plot new image
figure
image (targetBlack)
axis image

%%
clear, clc, close all;
rgb_image3 = imread ('test_image3.bmp');
fprintf ("Click on a target rectangle");
[targetRGB_vector] = ColorPicker(rgb_image3); %find RGB target value
[rowCoordVec, colCoordVec, rgb_image3] = FindAllTargetsCentroids(rgb_image3, targetRGB_vector);
rowCoordVec %display row coordinates
colCoordVec %display column coordinates
%plot new image
figure
image (rgb_image3)
axis image
%plot centoids on image
hold on
plot (colCoordVec, rowCoordVec, 'wx');