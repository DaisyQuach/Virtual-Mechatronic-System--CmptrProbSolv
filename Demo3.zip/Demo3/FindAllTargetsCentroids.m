function [rowCoordVec, colCoordVec, newImage] = FindAllTargetsCentroids(inputImage, targetRGB)
%Used to find the center of a target of a certain color
%Gavin Tobin, ME EN 1010, u1227373, HW10
for target = 1:6
    %overloaded FindTargetCentroid function to find all target centroids
    %and make the found targets black
    [rowCoord, colCoord, inputImage] = FindTargetCentroid(inputImage, targetRGB);
    rowCoordVec(target) = rowCoord;
    colCoordVec(target) = colCoord;
end
%give new image aray
newImage = inputImage;
end
    