%%
close all, clear, clc;
practiceImage1 = imread('S21_PP_A2.bmp');
fprintf ("Click on orange part of the basketball");
targetValues = ColorPicker (practiceImage1) %find target RGB values

targetValues = targetValues + 1; %add one to all values to find target RGB

[rowCoordVec, colCoordVec, targetsBlack] = FindAllTargetsCentroids(practiceImage1, targetValues);
rowCoordVec, colCoordVec %display row and column coordinates

%set up figure and plot image with centroids
figure
hold on
image (targetsBlack)
axis image
plot (colCoordVec, rowCoordVec, 'wx')
drawnow

%find target values to send to arduino
stripeNum = rowCoordVec ./ 10
xTarget = (colCoordVec + 750)./ 1000 %adjust for offset and convert to meters

%%
if (isempty(instrfind) == 0)
    fclose(instrfind)
    delete(instrfind)
end

% set up communication with the Romeo Board
RomeoCOM = serial('COM3', 'BaudRate', 9600);
fopen(RomeoCOM)

% wait for ready message from Romeo
while RomeoCOM.BytesAvailable == 0
   % do nothing (wait) 
end
readyMessage = fscanf(RomeoCOM);
readyMessage = readyMessage(1:end - 2); %gets rid of line returns
disp(readyMessage);

% write a value to Romeo Board (Sending strings)
for i = 1:6
    fprintf(RomeoCOM, '%d\n %1.3f\n', [stripeNum(i), xTarget(i)])
    i = i + 1;
    
    % read message from Romeo Board and display
    while RomeoCOM.BytesAvailable == 0
        % do nothing (wait) 
    end
    message = fscanf(RomeoCOM);
    message = message(1:end - 2); %gets rid of line returns
    disp(message)
end

% Scan for additional messages from Romeo until special end message
while (1)
    if RomeoCOM.BytesAvailable > 0
        message = fscanf(RomeoCOM);
        message = message(1:end - 2); %gets rid of line returns
        
        if length(message) == 0
            break
        end
        
        disp(message)  
    end
end

% disconnect from Romeo Board
fclose(RomeoCOM)
delete(RomeoCOM)
clear RomeoCOM